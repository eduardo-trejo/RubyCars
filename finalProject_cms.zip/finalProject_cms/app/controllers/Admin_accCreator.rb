class Admin::UsersController < Admin::AdminController

    def index
        authorize! :view_users, current_user
    end

    def new
        @user = User.new
        authorize! :create_users, current_user
        form_info
    end

    def create
        @user = User.new(user_parameter)
        authorize! :create_users, current_user
        if @user.save
            @user.deliver_activation_instructions!
            add_to_recent_user(@user)
            flash[:notice] = "Account has been created."
            redirect_to admin_users_url
        else
            form_info
            render action: :new
        end
    end
end
    
