class AccessController < ApplicationController

  def menu

  end

  def login

  end

  def attempt_login
    if params[:username].present? && params[:password].present?
      found_user = User.where(:username => params[:username]).first
      if found_user
        authorized_user = found_user.authenticate(params[:password])
        @name = params[:username]
      end
    end

    if authorized_user
      session[:user_id] = authorized_user.id
      flash[:notice] = "Welcome back, " + @name
      redirect_to(user_path)
    else
      flash.now[:notice] = "Invalid username/password."
      render('login')
    end

  end

  def logout
    session[:user_id] = nil
    flash[:notice] = "logged out successfully"
    redirect_to(access_login_path)
  end
end
