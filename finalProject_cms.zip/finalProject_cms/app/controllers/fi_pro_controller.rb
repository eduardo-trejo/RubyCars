class FiProController < ApplicationController

  layout false

  def index
    @cars = Car.sorted
  end

  def add_index
    
  end
end
