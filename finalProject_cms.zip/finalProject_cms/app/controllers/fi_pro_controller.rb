class FiProController < ApplicationController

  layout false

  def index
  end
end
