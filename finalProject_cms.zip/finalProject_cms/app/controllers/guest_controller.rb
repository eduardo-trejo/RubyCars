class GuestController < ApplicationController

  layout false
  def index
    @cars = Car.sorted
  end
end
