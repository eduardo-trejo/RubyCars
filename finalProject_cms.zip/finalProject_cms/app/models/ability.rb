class Ability
    include CanCan::Ability

    #This methods sets up admin and user abilities to view pages
    def initialize(user)
        user ||= User.new #guest user

        elseif user.admin?
            can :manage, :all
        else
            can :read, :user_id => user.id
            can :manage, Order do |action, order|
                action != :destroy && order.state !=  'complete' && order.user_id == user_id
            end
        end
    end
end