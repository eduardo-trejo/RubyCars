class AdminFunctions
    include CanCan::Ability

    def initialize(user)
        user ||=  User.new # guest users can't view admin section
        
        if user.admin?
            can :manage, :all
            can :read, :all
            can :view_users, User do
                user.admin?
            end

        can :create_users, User do
            user.admin?
        end
        
        can :create_orders, User
       else
       
       end
    end
end

