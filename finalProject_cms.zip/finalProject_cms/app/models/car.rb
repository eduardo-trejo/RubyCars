class Car < ApplicationRecord

  scope :sorted, lambda{order("bodystyle ASC")}
end
