class ShoppingCart < ApplicationRecord

  belongs_to :user

end
