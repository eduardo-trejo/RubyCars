class User < ApplicationRecord

  has_one :shopping_cart

end
