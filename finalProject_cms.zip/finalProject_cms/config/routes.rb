Rails.application.routes.draw do
  get 'guest/index'

  get 'fi_pro/index'

  root 'guest#index'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
