class CreateUsers < ActiveRecord::Migration[5.1]
  def up
    create_table :users do |t|
      t.column "firstname", :string, :limit => 30
      t.string "lastname", :limit => 50
      t.string "email", :default => '', :null => false
      t.string "password", :limit => 30

  end

  def down
    drop_table :users
  end
end
