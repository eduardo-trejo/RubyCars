class CreateCars < ActiveRecord::Migration[5.1]
  def change
    create_table :cars do |t|
      t.column "bodystyle", :string, :limit => 30
      t.column "mile", :float, :null => false
      t.column "year", :int, :null => false
      t.column "price", :int, :null => false

    end
  end
  def down
    drop_table :cars
  end
end
