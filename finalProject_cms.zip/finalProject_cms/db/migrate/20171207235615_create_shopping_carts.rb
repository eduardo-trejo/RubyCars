class CreateShoppingCarts < ActiveRecord::Migration[5.1]
  def change
    create_table :shopping_carts do |t|
        t.column "user_id", :int
        t.column "bodystyle", :string, :limit => 30, :null => false
        t.column "price", :int
      end
      add_index("shopping_carts", "user_id")
    end
    def down
      drop_table :shopping_carts
    end
end
