class AddUsernameToUsers < ActiveRecord::Migration[5.1]
    def up
      add_column "users", "username", :string, :limit => 40
    end

    def down
      remove_column "users", "username", :string, :limit => 40
    end
  
end
