require 'test_helper'

class FiProControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get fi_pro_index_url
    assert_response :success
  end

end
